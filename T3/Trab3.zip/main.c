#include "matrizes.h"

int main(){
	long long a;
	scanf("%lld", &a);
	fibo(a);
	return 0;
}